import UIKit

// Enum!
enum Operation {
    case add, subtract, multiply, divide
}
    
// Calculator 클래스!
class Calculator {
    var result: Double = 0
    
    // calculate 메서드!
    func calculate(operation: Operation, firstPad: Double, secondPad: Double) -> Double? {
        switch operation {
            // 더하기!
        case .add:
            return firstPad + secondPad
            // 빼기!
        case .subtract:
            return firstPad - secondPad
            // 곱하기!
        case .multiply:
            return firstPad * secondPad
            // 나누기!
        case .divide:
            return firstPad / secondPad
        }
    }
}

// 예제!
let calculator = Calculator()

// 더하기!
let addResult = calculator.calculate(operation: .add, firstPad: 10, secondPad: 20)
print("결과: \(addResult ?? 0)")

// 빼기!
let subtractionResult = calculator.calculate(operation: .subtract, firstPad: 10, secondPad: 5)
print("결과: \(subtractionResult ?? 0)")

// 곱하기!
let multiplicationResult = calculator.calculate(operation: .multiply, firstPad: 10, secondPad: 2)
print ("결과: \(multiplicationResult ?? 0)")

// 나누기!
let divisionResult = calculator.calculate(operation: .divide, firstPad: 20, secondPad: 2)
print("결과: \(divisionResult ?? 0)")
